import OpenAI from "openai";

// Reference: javascript_openai_ai_integrations blueprint
// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access without requiring your own OpenAI API key.
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

/**
 * Generate AI response for chat assistant
 */
export async function generateChatResponse(messages: ChatMessage[]): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages,
      max_completion_tokens: 1000,
    });

    return response.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate AI response");
  }
}

/**
 * System prompt for UnderItAll rug pad assistant
 */
export const SYSTEM_PROMPT = `You are a helpful shopping assistant for UnderItAll, a premium custom rug pad manufacturer specializing in perforated felt rug pads for design professionals.

Product Information:
- Custom-sized rug pads from 2-40 feet in any dimension
- Two thickness options: Luxe Lite (⅛") and Luxe (¼")
- Four shapes available: Rectangle, Round, Square, and Free Form
- Premium perforated felt construction for superior grip and protection
- Wholesale pricing for design professionals and contractors

Your role:
- Help customers find the right rug pad for their needs
- Answer questions about sizing, pricing, and product features
- Guide customers through the calculator tool for custom quotes
- Provide information about the wholesale trade program
- Be professional, helpful, and knowledgeable about rug pads

Keep responses concise and helpful. If asked about specific pricing, direct customers to use the calculator tool for accurate quotes based on their dimensions.`;
