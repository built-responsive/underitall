import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertWholesaleRegistrationSchema,
  insertCalculatorQuoteSchema,
  insertChatConversationSchema,
  insertChatMessageSchema,
  insertDraftOrderSchema,
} from "@shared/schema";
import { lookupPrice, calculateQuote, validateDimensions } from "./utils/pricingCalculator";
import bcrypt from "bcryptjs";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ============= WHOLESALE REGISTRATION ROUTES =============
  
  // Submit wholesale registration
  app.post("/api/wholesale-registration", async (req, res) => {
    try {
      const data = insertWholesaleRegistrationSchema.parse(req.body);
      
      // Check if email already exists
      const existing = await storage.getWholesaleRegistrationByEmail(data.email);
      if (existing) {
        return res.status(400).json({ 
          error: "An application with this email already exists" 
        });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(data.accountPassword, 10);
      
      const registration = await storage.createWholesaleRegistration({
        ...data,
        accountPassword: hashedPassword,
      });
      
      // Don't return password in response
      const { accountPassword, ...safeRegistration } = registration;
      
      res.json(safeRegistration);
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Registration failed" 
      });
    }
  });
  
  // Get all wholesale registrations (admin)
  app.get("/api/wholesale-registrations", async (req, res) => {
    try {
      const { status } = req.query;
      
      let registrations;
      if (status && typeof status === 'string') {
        registrations = await storage.getWholesaleRegistrationsByStatus(status);
      } else {
        registrations = await storage.getAllWholesaleRegistrations();
      }
      
      // Remove passwords from response
      const safe = registrations.map(({ accountPassword, ...reg }) => reg);
      
      res.json(safe);
    } catch (error) {
      console.error("Error fetching registrations:", error);
      res.status(500).json({ 
        error: "Failed to fetch registrations" 
      });
    }
  });
  
  // Get single wholesale registration
  app.get("/api/wholesale-registration/:id", async (req, res) => {
    try {
      const registration = await storage.getWholesaleRegistration(req.params.id);
      
      if (!registration) {
        return res.status(404).json({ error: "Registration not found" });
      }
      
      const { accountPassword, ...safeRegistration } = registration;
      res.json(safeRegistration);
    } catch (error) {
      console.error("Error fetching registration:", error);
      res.status(500).json({ 
        error: "Failed to fetch registration" 
      });
    }
  });
  
  // Update wholesale registration (admin approval/rejection)
  app.patch("/api/wholesale-registration/:id", async (req, res) => {
    try {
      const { status, adminNotes, rejectionReason } = req.body;
      
      const updates: any = { status };
      if (adminNotes) updates.adminNotes = adminNotes;
      if (rejectionReason) updates.rejectionReason = rejectionReason;
      
      if (status === 'approved') {
        updates.approvedAt = new Date();
        // In production, set approvedBy to current admin user ID
        // updates.approvedBy = req.user.id;
      }
      
      const updated = await storage.updateWholesaleRegistration(
        req.params.id,
        updates
      );
      
      if (!updated) {
        return res.status(404).json({ error: "Registration not found" });
      }
      
      const { accountPassword, ...safeRegistration } = updated;
      res.json(safeRegistration);
    } catch (error) {
      console.error("Error updating registration:", error);
      res.status(500).json({ 
        error: "Failed to update registration" 
      });
    }
  });
  
  // ============= CALCULATOR ROUTES =============
  
  // Calculate price (no persistence)
  app.post("/api/calculator/calculate", async (req, res) => {
    try {
      const { width, length, thickness, quantity = 1 } = req.body;
      
      // Validate dimensions
      const validation = validateDimensions(Number(width), Number(length));
      if (!validation.valid) {
        return res.status(400).json({ error: validation.error });
      }
      
      // Calculate price
      const result = calculateQuote(
        Number(width),
        Number(length),
        thickness === 'thick' ? 'thick' : 'thin',
        Number(quantity)
      );
      
      res.json(result);
    } catch (error) {
      console.error("Calculation error:", error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Calculation failed" 
      });
    }
  });
  
  // Save calculator quote
  app.post("/api/calculator/quote", async (req, res) => {
    try {
      const data = insertCalculatorQuoteSchema.parse(req.body);
      const quote = await storage.createCalculatorQuote(data);
      res.json(quote);
    } catch (error) {
      console.error("Error saving quote:", error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Failed to save quote" 
      });
    }
  });
  
  // Get all quotes (admin analytics)
  app.get("/api/calculator/quotes", async (req, res) => {
    try {
      const quotes = await storage.getAllCalculatorQuotes();
      res.json(quotes);
    } catch (error) {
      console.error("Error fetching quotes:", error);
      res.status(500).json({ 
        error: "Failed to fetch quotes" 
      });
    }
  });
  
  // Get quotes by wholesale customer
  app.get("/api/calculator/quotes/customer/:wholesaleId", async (req, res) => {
    try {
      const quotes = await storage.getCalculatorQuotesByWholesaleId(
        req.params.wholesaleId
      );
      res.json(quotes);
    } catch (error) {
      console.error("Error fetching customer quotes:", error);
      res.status(500).json({ 
        error: "Failed to fetch quotes" 
      });
    }
  });
  
  // ============= DRAFT ORDER ROUTES =============
  
  // Create Shopify draft order
  app.post("/api/draft-order", async (req, res) => {
    try {
      const { quoteId, customerInfo } = req.body;
      
      // Get the quote
      const quote = await storage.getCalculatorQuote(quoteId);
      if (!quote) {
        return res.status(404).json({ error: "Quote not found" });
      }
      
      // Check if Shopify credentials are available
      const shopDomain = process.env.SHOPIFY_SHOP_DOMAIN;
      const adminToken = process.env.SHOPIFY_ADMIN_ACCESS_TOKEN;
      
      if (!shopDomain || !adminToken) {
        // Shopify credentials not configured - return mock draft order
        const mockDraftOrder = {
          shopifyDraftOrderId: `draft_${Date.now()}`,
          shopifyDraftOrderUrl: `https://${shopDomain || 'underitall-redeux.myshopify.com'}/admin/draft_orders/mock_${Date.now()}`,
          invoiceUrl: `https://${shopDomain || 'underitall-redeux.myshopify.com'}/admin/draft_orders/mock_${Date.now()}/invoice`,
          totalPrice: quote.totalPrice,
          lineItems: [{
            title: `Custom Rug Pad - ${quote.shape} ${quote.thickness === 'thin' ? '⅛"' : '¼"'}`,
            quantity: quote.quantity,
            price: quote.totalPrice,
            custom_attributes: [
              { key: "Width", value: `${quote.width} ft` },
              { key: "Length", value: `${quote.length} ft` },
              { key: "Area", value: `${quote.area} sq ft` },
              { key: "Shape", value: quote.shape },
              { key: "Thickness", value: quote.thickness === 'thin' ? '⅛"' : '¼"' },
            ]
          }],
          calculatorQuoteId: quoteId,
          wholesaleRegistrationId: quote.wholesaleRegistrationId,
        };
        
        const draftOrder = await storage.createDraftOrder(mockDraftOrder);
        
        // Update quote with draft order info
        await storage.updateCalculatorQuote(quoteId, {
          shopifyDraftOrderId: draftOrder.shopifyDraftOrderId,
          shopifyDraftOrderUrl: draftOrder.shopifyDraftOrderUrl,
        });
        
        return res.json(draftOrder);
      }
      
      // Create actual Shopify draft order
      const lineItems = [{
        title: `Custom Rug Pad - ${quote.shape} ${quote.thickness === 'thin' ? '⅛"' : '¼"'}`,
        quantity: quote.quantity,
        price: String(quote.totalPrice),
        taxable: true,
        custom_attributes: [
          { key: "Width", value: `${quote.width} ft` },
          { key: "Length", value: `${quote.length} ft` },
          { key: "Area", value: `${quote.area} sq ft` },
          { key: "Shape", value: quote.shape },
          { key: "Thickness", value: quote.thickness === 'thin' ? '⅛"' : '¼"' },
          { key: "Price per sq ft", value: `$${quote.pricePerSqFt}` },
        ]
      }];
      
      if (quote.projectName) {
        lineItems[0].custom_attributes?.push({
          key: "Project Name",
          value: quote.projectName
        });
      }
      
      const draftOrderData = {
        draft_order: {
          line_items: lineItems,
          customer: customerInfo,
          note: quote.notes || `Calculator Quote #${quote.id}`,
          tags: "calculator-quote, wholesale",
        }
      };
      
      const response = await fetch(
        `https://${shopDomain}/admin/api/2024-01/draft_orders.json`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Shopify-Access-Token": adminToken,
          },
          body: JSON.stringify(draftOrderData),
        }
      );
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Shopify API error: ${response.status} - ${errorText}`);
      }
      
      const shopifyData = await response.json();
      const shopifyDraftOrder = shopifyData.draft_order;
      
      // Save draft order to database
      const draftOrder = await storage.createDraftOrder({
        shopifyDraftOrderId: String(shopifyDraftOrder.id),
        shopifyDraftOrderUrl: `https://${shopDomain}/admin/draft_orders/${shopifyDraftOrder.id}`,
        invoiceUrl: shopifyDraftOrder.invoice_url,
        totalPrice: shopifyDraftOrder.total_price,
        lineItems: shopifyDraftOrder.line_items,
        calculatorQuoteId: quoteId,
        wholesaleRegistrationId: quote.wholesaleRegistrationId,
      });
      
      // Update quote with draft order info
      await storage.updateCalculatorQuote(quoteId, {
        shopifyDraftOrderId: draftOrder.shopifyDraftOrderId,
        shopifyDraftOrderUrl: draftOrder.shopifyDraftOrderUrl,
      });
      
      res.json(draftOrder);
    } catch (error) {
      console.error("Draft order creation error:", error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : "Failed to create draft order" 
      });
    }
  });
  
  // Get all draft orders (admin)
  app.get("/api/draft-orders", async (req, res) => {
    try {
      const orders = await storage.getAllDraftOrders();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching draft orders:", error);
      res.status(500).json({ 
        error: "Failed to fetch draft orders" 
      });
    }
  });
  
  // ============= CHAT ROUTES =============
  
  // Create chat conversation
  app.post("/api/chat/conversation", async (req, res) => {
    try {
      const data = insertChatConversationSchema.parse(req.body);
      const conversation = await storage.createChatConversation(data);
      res.json(conversation);
    } catch (error) {
      console.error("Error creating conversation:", error);
      res.status(400).json({ 
        error: "Failed to create conversation" 
      });
    }
  });
  
  // Get conversation by session
  app.get("/api/chat/conversation/session/:sessionId", async (req, res) => {
    try {
      const conversations = await storage.getChatConversationsBySession(
        req.params.sessionId
      );
      res.json(conversations);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      res.status(500).json({ 
        error: "Failed to fetch conversations" 
      });
    }
  });
  
  // Get messages for conversation
  app.get("/api/chat/conversation/:id/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessagesByConversation(
        req.params.id
      );
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ 
        error: "Failed to fetch messages" 
      });
    }
  });
  
  // Send chat message (with AI response)
  app.post("/api/chat/message", async (req, res) => {
    try {
      const { conversationId, content, sessionId } = req.body;
      
      // Get or create conversation
      let conversation;
      if (conversationId) {
        conversation = await storage.getChatConversation(conversationId);
      } else if (sessionId) {
        // Create new conversation for this session
        conversation = await storage.createChatConversation({
          sessionId,
          isActive: true,
        });
      }
      
      if (!conversation) {
        return res.status(404).json({ error: "Conversation not found" });
      }
      
      // Save user message
      const userMessage = await storage.createChatMessage({
        conversationId: conversation.id,
        role: "user",
        content,
      });
      
      // Get conversation history
      const messages = await storage.getChatMessagesByConversation(conversation.id);
      
      // Generate AI response
      const { generateChatResponse, SYSTEM_PROMPT } = await import("./utils/openai");
      
      const chatHistory = [
        { role: "system" as const, content: SYSTEM_PROMPT },
        ...messages.map((msg) => ({
          role: msg.role as "user" | "assistant",
          content: msg.content,
        })),
      ];
      
      const aiResponse = await generateChatResponse(chatHistory);
      
      // Save AI message
      const assistantMessage = await storage.createChatMessage({
        conversationId: conversation.id,
        role: "assistant",
        content: aiResponse,
      });
      
      // Update conversation title if first message
      if (messages.length === 1) {
        await storage.updateChatConversation(conversation.id, {
          title: content.slice(0, 50) + (content.length > 50 ? "..." : ""),
        });
      }
      
      res.json({
        userMessage,
        assistantMessage,
        conversationId: conversation.id,
      });
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(400).json({ 
        error: error instanceof Error ? error.message : "Failed to send message" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
