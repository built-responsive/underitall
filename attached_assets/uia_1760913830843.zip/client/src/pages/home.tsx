import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator, Users, LayoutDashboard, MessageSquare } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[hsl(48,21%,95%)] to-[hsl(60,5%,88%)]">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold mb-4 font-[Archivo]" data-testid="text-page-title">
            UnderItAll
          </h1>
          <p className="text-2xl italic font-[Lora] text-muted-foreground mb-8" data-testid="text-page-subtitle">
            Premium Custom Rug Pads for Design Professionals
          </p>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Professional-grade perforated felt rug pads, custom-cut to your exact specifications with wholesale pricing for the trade
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
          <Card className="hover-elevate">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Calculator className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="font-[Archivo]">Rug Pad Calculator</CardTitle>
              <CardDescription>
                Get instant pricing for custom-sized rug pads with our real-time calculator
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/calculator">
                <Button className="w-full" data-testid="link-calculator">
                  Open Calculator
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="font-[Archivo]">Wholesale Registration</CardTitle>
              <CardDescription>
                Join our trade program to access wholesale pricing and custom orders
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/wholesale-registration">
                <Button className="w-full" data-testid="link-wholesale">
                  Apply Now
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <LayoutDashboard className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="font-[Archivo]">Admin Dashboard</CardTitle>
              <CardDescription>
                Manage wholesale registrations, view analytics, and create draft orders
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/admin">
                <Button variant="outline" className="w-full" data-testid="link-admin">
                  Access Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <MessageSquare className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="font-[Archivo]">AI Shopping Assistant</CardTitle>
              <CardDescription>
                Get product recommendations and answers to your questions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full" disabled data-testid="button-chat">
                Coming Soon
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold mb-8 font-[Archivo]">Why Choose UnderItAll?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div>
              <h3 className="text-xl font-semibold mb-2 font-[Archivo]">Custom Sizing</h3>
              <p className="text-muted-foreground">
                Precision-cut rug pads from 2-40 feet in any dimension
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2 font-[Archivo]">Wholesale Pricing</h3>
              <p className="text-muted-foreground">
                Volume-based pricing for design professionals and contractors
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2 font-[Archivo]">Premium Quality</h3>
              <p className="text-muted-foreground">
                Perforated felt construction for superior grip and protection
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
