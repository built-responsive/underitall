import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { Ruler, CircleDot, Square, Sparkles, Plus, Minus } from "lucide-react";

const calculatorSchema = z.object({
  width: z.number().min(2, "Minimum 2 feet").max(40, "Maximum 40 feet"),
  length: z.number().min(2, "Minimum 2 feet").max(40, "Maximum 40 feet"),
  thickness: z.enum(["thin", "thick"]),
  shape: z.enum(["rectangle", "round", "square", "freeform"]),
  quantity: z.number().min(1).default(1),
  projectName: z.string().optional(),
  clientName: z.string().optional(),
  notes: z.string().optional(),
});

type CalculatorFormData = z.infer<typeof calculatorSchema>;

export default function Calculator() {
  const { toast } = useToast();
  const [priceData, setPriceData] = useState<any>(null);

  const form = useForm<CalculatorFormData>({
    resolver: zodResolver(calculatorSchema),
    defaultValues: {
      width: 8,
      length: 10,
      thickness: "thin",
      shape: "rectangle",
      quantity: 1,
      projectName: "",
      clientName: "",
      notes: "",
    },
  });

  const width = form.watch("width");
  const length = form.watch("length");
  const thickness = form.watch("thickness");
  const quantity = form.watch("quantity");

  // Calculate price in real-time
  const calculateMutation = useMutation({
    mutationFn: async (data: { width: number; length: number; thickness: string; quantity: number }) => {
      const res = await apiRequest("POST", "/api/calculator/calculate", data);
      return await res.json();
    },
    onSuccess: (data) => {
      setPriceData(data);
    },
  });

  // Trigger calculation when dimensions change
  useEffect(() => {
    if (width && length) {
      calculateMutation.mutate({ width, length, thickness, quantity });
    }
  }, [width, length, thickness, quantity]);

  // Save quote
  const saveQuoteMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/calculator/quote", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Quote Saved",
        description: "Your calculator quote has been saved.",
      });
    },
  });

  // Create draft order
  const createDraftOrderMutation = useMutation({
    mutationFn: async (quoteId: string) => {
      const res = await apiRequest("POST", "/api/draft-order", { quoteId });
      return await res.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Draft Order Created",
        description: "Your Shopify draft order has been created successfully.",
      });
      window.open(data.shopifyDraftOrderUrl, "_blank");
    },
  });

  const handleCalculate = () => {
    const values = form.getValues();
    calculateMutation.mutate({
      width: values.width,
      length: values.length,
      thickness: values.thickness,
      quantity: values.quantity,
    });
  };

  const handleSaveQuote = async () => {
    const values = form.getValues();
    if (!priceData) {
      toast({
        title: "Calculate First",
        description: "Please calculate a price before saving.",
        variant: "destructive",
      });
      return;
    }

    const quoteData = {
      width: String(values.width),
      length: String(values.length),
      shape: values.shape,
      thickness: values.thickness,
      area: String(priceData.area),
      pricePerSqFt: String(priceData.pricePerSqFt),
      totalPrice: String(priceData.total),
      quantity: values.quantity,
      projectName: values.projectName,
      clientName: values.clientName,
      notes: values.notes,
    };

    const savedQuote = await saveQuoteMutation.mutateAsync(quoteData);
    return savedQuote;
  };

  const handleCreateDraftOrder = async () => {
    const savedQuote: any = await handleSaveQuote();
    if (savedQuote?.id) {
      createDraftOrderMutation.mutate(savedQuote.id);
    }
  };

  const shapeIcons = {
    rectangle: Ruler,
    round: CircleDot,
    square: Square,
    freeform: Sparkles,
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[hsl(48,21%,95%)] to-[hsl(60,5%,88%)]">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 font-[Archivo]" data-testid="text-page-title">
            Custom Rug Pad Calculator
          </h1>
          <p className="text-xl italic font-[Lora] text-muted-foreground" data-testid="text-page-subtitle">
            Get instant pricing for custom-sized perforated rug pads
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-7xl mx-auto">
          {/* Left Column - Input Form */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-[Archivo]">Dimensions</CardTitle>
                <CardDescription>Enter your rug pad measurements (2-40 feet)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Form {...form}>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="width"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Width (feet)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.1"
                              min="2"
                              max="40"
                              {...field}
                              onChange={(e) => {
                                field.onChange(parseFloat(e.target.value) || 0);
                                handleCalculate();
                              }}
                              data-testid="input-width"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="length"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Length (feet)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              step="0.1"
                              min="2"
                              max="40"
                              {...field}
                              onChange={(e) => {
                                field.onChange(parseFloat(e.target.value) || 0);
                                handleCalculate();
                              }}
                              data-testid="input-length"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-[Archivo]">Product Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Form {...form}>
                  <FormField
                    control={form.control}
                    name="thickness"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Thickness</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={(value) => {
                              field.onChange(value);
                              handleCalculate();
                            }}
                            value={field.value}
                            className="grid grid-cols-2 gap-4"
                          >
                            <div>
                              <RadioGroupItem
                                value="thin"
                                id="thin"
                                className="peer sr-only"
                                data-testid="radio-thin"
                              />
                              <Label
                                htmlFor="thin"
                                className="flex flex-col items-center justify-center p-4 border-2 rounded-lg cursor-pointer hover-elevate peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                              >
                                <span className="font-semibold">Luxe Lite ⅛"</span>
                                <span className="text-sm text-muted-foreground">Thin Profile</span>
                              </Label>
                            </div>
                            <div>
                              <RadioGroupItem
                                value="thick"
                                id="thick"
                                className="peer sr-only"
                                data-testid="radio-thick"
                              />
                              <Label
                                htmlFor="thick"
                                className="flex flex-col items-center justify-center p-4 border-2 rounded-lg cursor-pointer hover-elevate peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                              >
                                <span className="font-semibold">Luxe ¼"</span>
                                <span className="text-sm text-muted-foreground">Standard Cushion</span>
                              </Label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="shape"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Shape</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            value={field.value}
                            className="grid grid-cols-4 gap-2"
                          >
                            {(["rectangle", "round", "square", "freeform"] as const).map((shape) => {
                              const Icon = shapeIcons[shape];
                              return (
                                <div key={shape}>
                                  <RadioGroupItem
                                    value={shape}
                                    id={shape}
                                    className="peer sr-only"
                                    data-testid={`radio-${shape}`}
                                  />
                                  <Label
                                    htmlFor={shape}
                                    className="flex flex-col items-center justify-center p-3 border-2 rounded-lg cursor-pointer hover-elevate peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                                  >
                                    <Icon className="w-6 h-6 mb-1" />
                                    <span className="text-xs capitalize">{shape}</span>
                                  </Label>
                                </div>
                              );
                            })}
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantity</FormLabel>
                        <FormControl>
                          <div className="flex items-center gap-2">
                            <Button
                              type="button"
                              size="icon"
                              variant="outline"
                              onClick={() => {
                                const newVal = Math.max(1, field.value - 1);
                                field.onChange(newVal);
                                handleCalculate();
                              }}
                              data-testid="button-quantity-decrease"
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                            <Input
                              type="number"
                              min="1"
                              {...field}
                              onChange={(e) => {
                                field.onChange(parseInt(e.target.value) || 1);
                                handleCalculate();
                              }}
                              className="text-center"
                              data-testid="input-quantity"
                            />
                            <Button
                              type="button"
                              size="icon"
                              variant="outline"
                              onClick={() => {
                                field.onChange(field.value + 1);
                                handleCalculate();
                              }}
                              data-testid="button-quantity-increase"
                            >
                              <Plus className="w-4 h-4" />
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </Form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-[Archivo]">Project Details (Optional)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Form {...form}>
                  <FormField
                    control={form.control}
                    name="projectName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Client residence renovation" {...field} data-testid="input-project-name" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="clientName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Client Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Jane Smith" {...field} data-testid="input-client-name" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Additional requirements..." {...field} data-testid="textarea-notes" />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Quote Preview */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            <Card>
              <CardHeader>
                <CardTitle className="font-[Archivo]">Quote Preview</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {priceData ? (
                  <>
                    <div className="text-center py-6 border-b">
                      <div className="text-5xl font-bold text-primary mb-2" data-testid="text-total-price">
                        ${(priceData.grandTotal || priceData.total).toFixed(2)}
                      </div>
                      <div className="text-sm text-muted-foreground">Total Price</div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Dimensions</span>
                        <span className="font-medium" data-testid="text-dimensions">
                          {width} × {length} ft
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Area</span>
                        <span className="font-medium" data-testid="text-area">{priceData.area.toFixed(2)} sq ft</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Price per sq ft</span>
                        <span className="font-medium" data-testid="text-price-per-sqft">${priceData.pricePerSqFt.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Thickness</span>
                        <span className="font-medium" data-testid="text-thickness">
                          {thickness === "thin" ? "⅛ inch" : "¼ inch"}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Quantity</span>
                        <span className="font-medium" data-testid="text-quantity">{quantity}</span>
                      </div>
                    </div>

                    <div className="space-y-2 pt-4 border-t">
                      <p className="text-sm italic font-[Lora] text-muted-foreground">
                        Premium perforated felt rug pad, custom-cut to your specifications
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Button
                        className="w-full"
                        onClick={handleSaveQuote}
                        disabled={saveQuoteMutation.isPending}
                        data-testid="button-save-quote"
                      >
                        {saveQuoteMutation.isPending ? "Saving..." : "Save Quote"}
                      </Button>
                      <Button
                        className="w-full"
                        variant="outline"
                        onClick={handleCreateDraftOrder}
                        disabled={createDraftOrderMutation.isPending}
                        data-testid="button-create-draft-order"
                      >
                        {createDraftOrderMutation.isPending ? "Creating..." : "Create Draft Order"}
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <p>Enter dimensions to calculate pricing</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
