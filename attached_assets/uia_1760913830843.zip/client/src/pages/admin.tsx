import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Users, Calculator, FileText, CheckCircle, XCircle, Clock } from "lucide-react";
import { format } from "date-fns";

export default function Admin() {
  const { toast } = useToast();
  const [selectedRegistration, setSelectedRegistration] = useState<any>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [rejectionReason, setRejectionReason] = useState("");
  const [actionType, setActionType] = useState<"approve" | "reject" | null>(null);

  // Fetch wholesale registrations
  const { data: registrations = [], isLoading: loadingRegistrations } = useQuery({
    queryKey: ["/api/wholesale-registrations"],
  });

  // Fetch calculator quotes for analytics
  const { data: quotes = [], isLoading: loadingQuotes } = useQuery({
    queryKey: ["/api/calculator/quotes"],
  });

  // Fetch draft orders
  const { data: draftOrders = [], isLoading: loadingOrders } = useQuery({
    queryKey: ["/api/draft-orders"],
  });

  // Update registration mutation
  const updateRegistrationMutation = useMutation({
    mutationFn: async ({ id, status, adminNotes, rejectionReason }: any) => {
      const res = await apiRequest("PATCH", `/api/wholesale-registration/${id}`, { status, adminNotes, rejectionReason });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wholesale-registrations"] });
      setSelectedRegistration(null);
      setAdminNotes("");
      setRejectionReason("");
      setActionType(null);
      toast({
        title: "Registration Updated",
        description: "The registration status has been updated successfully.",
      });
    },
  });

  const handleApprove = (registration: any) => {
    setSelectedRegistration(registration);
    setActionType("approve");
  };

  const handleReject = (registration: any) => {
    setSelectedRegistration(registration);
    setActionType("reject");
  };

  const confirmAction = () => {
    if (!selectedRegistration || !actionType) return;

    updateRegistrationMutation.mutate({
      id: selectedRegistration.id,
      status: actionType === "approve" ? "approved" : "rejected",
      adminNotes,
      rejectionReason: actionType === "reject" ? rejectionReason : undefined,
    });
  };

  const pendingCount = registrations.filter((r: any) => r.status === "pending").length;
  const approvedCount = registrations.filter((r: any) => r.status === "approved").length;
  const totalQuotes = quotes.length;
  const totalOrders = draftOrders.length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold font-[Archivo]" data-testid="text-page-title">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage wholesale registrations and view analytics</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Applications</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-pending-count">{pendingCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Approved Customers</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-approved-count">{approvedCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Calculator Quotes</CardTitle>
              <Calculator className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-quotes-count">{totalQuotes}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Draft Orders</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-orders-count">{totalOrders}</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="registrations" className="space-y-4">
          <TabsList>
            <TabsTrigger value="registrations" data-testid="tab-registrations">Registrations</TabsTrigger>
            <TabsTrigger value="quotes" data-testid="tab-quotes">Calculator Quotes</TabsTrigger>
            <TabsTrigger value="orders" data-testid="tab-orders">Draft Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="registrations">
            <Card>
              <CardHeader>
                <CardTitle>Wholesale Registrations</CardTitle>
                <CardDescription>Review and approve wholesale applications</CardDescription>
              </CardHeader>
              <CardContent>
                {loadingRegistrations ? (
                  <div className="text-center py-8">Loading...</div>
                ) : registrations.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No registrations yet</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Firm Name</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Business Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {registrations.map((reg: any) => (
                        <TableRow key={reg.id} data-testid={`row-registration-${reg.id}`}>
                          <TableCell className="font-medium">{reg.firmName}</TableCell>
                          <TableCell>
                            <div>{reg.contactName}</div>
                            <div className="text-sm text-muted-foreground">{reg.email}</div>
                          </TableCell>
                          <TableCell className="capitalize">{reg.businessType.replace("_", " ")}</TableCell>
                          <TableCell>{getStatusBadge(reg.status)}</TableCell>
                          <TableCell>{format(new Date(reg.createdAt), "MMM d, yyyy")}</TableCell>
                          <TableCell>
                            {reg.status === "pending" && (
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => handleApprove(reg)}
                                  data-testid={`button-approve-${reg.id}`}
                                >
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleReject(reg)}
                                  data-testid={`button-reject-${reg.id}`}
                                >
                                  Reject
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quotes">
            <Card>
              <CardHeader>
                <CardTitle>Calculator Quotes</CardTitle>
                <CardDescription>View all saved calculator quotes</CardDescription>
              </CardHeader>
              <CardContent>
                {loadingQuotes ? (
                  <div className="text-center py-8">Loading...</div>
                ) : quotes.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No quotes yet</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Dimensions</TableHead>
                        <TableHead>Shape</TableHead>
                        <TableHead>Thickness</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Project</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {quotes.map((quote: any) => (
                        <TableRow key={quote.id}>
                          <TableCell>{quote.width} × {quote.length} ft</TableCell>
                          <TableCell className="capitalize">{quote.shape}</TableCell>
                          <TableCell>{quote.thickness === "thin" ? "⅛\"" : "¼\""}</TableCell>
                          <TableCell className="font-medium">${quote.totalPrice}</TableCell>
                          <TableCell>{quote.projectName || "—"}</TableCell>
                          <TableCell>{format(new Date(quote.createdAt), "MMM d, yyyy")}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Draft Orders</CardTitle>
                <CardDescription>View all created draft orders</CardDescription>
              </CardHeader>
              <CardContent>
                {loadingOrders ? (
                  <div className="text-center py-8">Loading...</div>
                ) : draftOrders.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">No draft orders yet</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Total Price</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {draftOrders.map((order: any) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-mono text-sm">{order.shopifyDraftOrderId}</TableCell>
                          <TableCell className="font-medium">${order.totalPrice}</TableCell>
                          <TableCell>{format(new Date(order.createdAt), "MMM d, yyyy")}</TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(order.shopifyDraftOrderUrl, "_blank")}
                            >
                              View in Shopify
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Approval/Rejection Dialog */}
      <Dialog open={!!selectedRegistration} onOpenChange={() => setSelectedRegistration(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === "approve" ? "Approve" : "Reject"} Registration
            </DialogTitle>
            <DialogDescription>
              {actionType === "approve"
                ? "Approve this wholesale registration application"
                : "Reject this wholesale registration application"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {selectedRegistration && (
              <div className="space-y-2 text-sm">
                <div><strong>Firm:</strong> {selectedRegistration.firmName}</div>
                <div><strong>Contact:</strong> {selectedRegistration.contactName}</div>
                <div><strong>Email:</strong> {selectedRegistration.email}</div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="adminNotes">Admin Notes (Optional)</Label>
              <Textarea
                id="adminNotes"
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                placeholder="Internal notes about this decision..."
                data-testid="textarea-admin-notes"
              />
            </div>

            {actionType === "reject" && (
              <div className="space-y-2">
                <Label htmlFor="rejectionReason">Rejection Reason</Label>
                <Textarea
                  id="rejectionReason"
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Reason for rejection (will be sent to applicant)..."
                  data-testid="textarea-rejection-reason"
                />
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedRegistration(null)}>
              Cancel
            </Button>
            <Button
              onClick={confirmAction}
              disabled={updateRegistrationMutation.isPending}
              data-testid="button-confirm-action"
            >
              {updateRegistrationMutation.isPending ? "Processing..." : "Confirm"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
