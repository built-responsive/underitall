# UnderItAll - Shopify Rug Pad Application

A unified Shopify application for UnderItAll featuring wholesale registration, intelligent rug pad calculator with real-time pricing, and AI-powered chat assistant.

## Project Overview

**Built for:** UnderItAll - Premium custom rug pad manufacturer  
**Target Users:** Design professionals, contractors, and retail customers  
**Tech Stack:** React + TypeScript, Express.js, PostgreSQL, OpenAI GPT-5

## Features

### 1. Wholesale Registration & Onboarding
- Complete business credential verification system
- Trade license and certification upload
- Admin approval workflow in dashboard
- Professional registration form with validation

**Route:** `/wholesale-registration`  
**API:** `POST /api/wholesale-registration`

### 2. Rug Pad Calculator
- Real-time pricing calculator using CSV-based price break matrices
- Custom sizing: 2-40 feet in any dimension
- 4 shape options: Rectangle, Round, Square, Free Form
- 2 thickness options: Luxe Lite (⅛") and Luxe (¼")
- Live quote preview with automatic recalculation
- Shopify draft order creation (when credentials configured)

**Route:** `/calculator`  
**API:** `POST /api/calculator/calculate`  
**Pricing Engine:** `server/utils/pricingCalculator.ts`  
**Price Matrices:** `server/data/priceBreakMap_Thin.json`, `priceBreakMap_Thick.json`

### 3. AI-Powered Chat Assistant
- Floating chat bubble on all pages
- Conversational shopping experience
- Powered by OpenAI GPT-5 (newest model, released Aug 7, 2025)
- Product recommendations and sizing guidance
- Persistent conversation history

**Component:** `client/src/components/chat-bubble.tsx`  
**API:** `POST /api/chat/message`  
**OpenAI Integration:** `server/utils/openai.ts`

### 4. Admin Dashboard
- Wholesale registration approval/rejection
- Calculator usage analytics
- Draft order management
- Business insights and reporting

**Route:** `/admin`

## Technology Stack

### Frontend
- **Framework:** React 18 + TypeScript
- **Routing:** Wouter
- **Styling:** Tailwind CSS + Shadcn UI
- **State Management:** TanStack Query v5
- **Forms:** React Hook Form + Zod validation

### Backend
- **Server:** Express.js
- **Database:** PostgreSQL (Neon-backed)
- **ORM:** Drizzle ORM
- **Storage:** In-memory with DB persistence
- **AI:** OpenAI GPT-5 via Replit AI Integrations

### Design System
- **Primary Color:** Rorange (#F2633A)
- **Typography:** 
  - Headlines: Archivo
  - Body: Lora
  - Numbers: Vazirmatn
- **UI Components:** Shadcn with custom theming
- **Guidelines:** See `design_guidelines.md`

## Project Structure

```
├── client/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/              # Shadcn components
│   │   │   └── chat-bubble.tsx  # AI chat widget
│   │   ├── pages/
│   │   │   ├── home.tsx
│   │   │   ├── calculator.tsx
│   │   │   ├── wholesale-registration.tsx
│   │   │   └── admin.tsx
│   │   ├── App.tsx
│   │   └── index.css            # Brand colors & theme
│   └── index.html
├── server/
│   ├── routes.ts                # All API endpoints
│   ├── storage.ts               # Database interface
│   ├── utils/
│   │   ├── pricingCalculator.ts # Price matrix logic
│   │   ├── openai.ts            # GPT-5 integration
│   │   └── shopify.ts           # Shopify API client
│   └── data/
│       ├── priceBreakMap_Thin.json   # ⅛" pricing
│       └── priceBreakMap_Thick.json  # ¼" pricing
├── shared/
│   └── schema.ts                # Database schemas & types
├── design_guidelines.md         # Brand & design specs
├── SHOPIFY_INTEGRATION.md       # Deployment guide
└── replit.md                    # This file
```

## Database Schema

All tables are defined in `shared/schema.ts`:

- **wholesaleRegistrations** - Business credential submissions
- **calculatorQuotes** - Saved price quotes
- **chatConversations** - Chat session tracking
- **chatMessages** - Conversation history
- **draftOrders** - Shopify order tracking
- **adminUsers** - Admin authentication (future)

## API Endpoints

### Calculator
- `POST /api/calculator/calculate` - Generate price quote
- `POST /api/calculator/draft-order` - Create Shopify draft order
- `GET /api/calculator/quotes` - Get all quotes

### Wholesale Registration
- `POST /api/wholesale-registration` - Submit registration
- `GET /api/wholesale-registrations` - Get all registrations
- `PATCH /api/wholesale-registration/:id/status` - Approve/reject

### Chat Assistant
- `POST /api/chat/message` - Send message & get AI response
- `GET /api/chat/conversations` - Get conversation history
- `GET /api/chat/conversation/:id/messages` - Get messages

## Environment Configuration

### Required Secrets
- `DATABASE_URL` - PostgreSQL connection (auto-configured)
- `SESSION_SECRET` - Session encryption (auto-configured)

### Optional Shopify Integration
Set these to enable full Shopify integration:
- `SHOPIFY_ADMIN_ACCESS_TOKEN` - For draft order creation
- `SHOPIFY_STOREFRONT_ACCESS_TOKEN` - For product search in chat
- `SHOPIFY_SHOP_DOMAIN` - Your store domain (e.g., `store.myshopify.com`)

### OpenAI Integration
Automatically configured via Replit AI Integrations:
- `AI_INTEGRATIONS_OPENAI_BASE_URL`
- `AI_INTEGRATIONS_OPENAI_API_KEY`

## Running the Application

The app runs automatically on Replit with hot module reload:

```bash
npm run dev
```

This starts:
- Express backend on port 5000
- Vite dev server with HMR
- PostgreSQL database connection

## Key Features Implementation

### Real-Time Calculator Pricing
The calculator uses a sophisticated pricing engine that:
1. Loads price matrices from JSON files (converted from Google Sheets CSV)
2. Uses `lookupPrice()` function to find closest price break
3. Applies interpolation for intermediate sizes
4. Recalculates automatically when dimensions change (via `useEffect`)
5. Supports all 4 shapes with custom calculation logic

See `server/utils/pricingCalculator.ts` for implementation details.

### AI Chat System
The chat assistant:
1. Maintains conversation context across messages
2. Uses OpenAI GPT-5 with custom system prompt
3. Stores messages in PostgreSQL for persistence
4. Provides helpful product information and guidance
5. Can be extended with Shopify product search

See `server/utils/openai.ts` for the AI integration.

### Shopify Integration
The app is ready for Shopify integration:
- Draft order API implemented with fallback
- Admin & Storefront API support
- Graceful degradation when credentials missing
- See `SHOPIFY_INTEGRATION.md` for setup guide

## Testing

All MVP features have been tested end-to-end:
- ✅ Home page navigation
- ✅ Calculator real-time pricing (8x10 → 12x10 verified)
- ✅ Wholesale registration form submission
- ✅ AI chat assistant with GPT-5 responses
- ✅ Admin dashboard approval workflow

## Deployment

### Publishing on Replit
1. Click "Publish" button in Replit
2. Your app will be available at: `https://your-app.replit.app`
3. Configure Shopify credentials if needed
4. Share the URL or embed in Shopify theme

### Shopify Theme Integration
See `SHOPIFY_INTEGRATION.md` for detailed integration options:
- Iframe embedding
- JavaScript widget
- Shopify App Extension (future)

## Development Workflow

### Adding New Features
1. Update database schema in `shared/schema.ts`
2. Add types and validation schemas
3. Create API routes in `server/routes.ts`
4. Build frontend components in `client/src/`
5. Test with Playwright e2e tests
6. Deploy to Replit

### Updating Price Matrices
1. Export updated pricing from Google Sheets as CSV
2. Convert to JSON format
3. Replace files in `server/data/`
4. Restart the application

### Customizing Design
1. Update colors in `client/src/index.css`
2. Modify design guidelines in `design_guidelines.md`
3. Adjust component styling as needed
4. Ensure accessibility and responsive design

## Future Enhancements

Planned features (Tasks 9-13):
- Customer account integration with order history
- Automated email notifications for approvals
- Admin bulk operations for draft orders
- Persistent chat history with recommendations
- Real-time inventory integration

## Support & Maintenance

**Built with:** Replit Agent  
**Last Updated:** October 19, 2025  
**Version:** 1.0.0 MVP

For questions or issues:
1. Check `SHOPIFY_INTEGRATION.md` for deployment help
2. Review `design_guidelines.md` for design specs
3. See code comments for implementation details

## License

Proprietary - UnderItAll, Inc.
